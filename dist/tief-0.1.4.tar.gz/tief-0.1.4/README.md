# TIEF AI Library

TIEF.ai is an AI library for research and study purpose. This library is very easy to use. If you found some lack of performance or some issues, just tell me. I'll upgrade it as soon as possible.

License
----

MIT


**Lest Rock!**